<?php $__env->startSection('content'); ?>
<link href="/css/home.css" rel="stylesheet">
        <div class="home">
            <div class="parallax"><h1>Rattrapage TODO</h1></div>
        </div>

        <div class="home2">

        </div>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Diizo portable\Desktop\todo\resources\views/home.blade.php ENDPATH**/ ?>