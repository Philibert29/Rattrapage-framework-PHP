<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Styles -->
    <link href="/css/app.css" rel="stylesheet">
</head>


<!----- BODY ----->
<body>

    <div class="app">
        <div class="navbar">
            <a class="accueil" href="<?php echo e(url('/')); ?>">
                Accueil
            </a>
            
                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                        <?php if(Route::has('login')): ?>
                            <a class="login" href="<?php echo e(route('login')); ?>">Se connecter</a>
                        <?php endif; ?>

                        <?php if(Route::has('register')): ?>
                            <a class="login" href="<?php echo e(route('register')); ?>">S'enregistrer</a>
                        <?php endif; ?>
                        <?php else: ?>
                            <!--<a class="login" id="navbarDropdown" href="http://127.0.0.1:8000/profiles/<?php echo e(Auth::user()->username); ?>" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                Profil
                            </a>-->
                                <a class="login" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                                        Se déconnecter
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" >
                                        <?php echo csrf_field(); ?>
                                    </form>
                        <?php endif; ?>
                </div>
</div>

        <main class="">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Diizo portable\Desktop\todo\resources\views/layouts/app.blade.php ENDPATH**/ ?>