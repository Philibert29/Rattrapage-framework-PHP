

<?php $__env->startSection('content'); ?>
<link href="/css/show.css" rel="stylesheet">
<div class="div1"></div>
<div>Nom d'utilisateur : <?php echo e($user->username); ?></div>

<div class="mr-3"><strong><?php echo e($user->posts->count()); ?></strong> publications</div>
<div class="post"><a class="" href="<?php echo e(route('posts.create')); ?>">Créer un post</a></div>

<div class="div2">
	<?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-4">
			<img src="<?php echo e(asset('storage') . '/' . $post->image); ?>" classe="w-100">
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Diizo portable\Desktop\projet_uf\resources\views/profiles/show.blade.php ENDPATH**/ ?>