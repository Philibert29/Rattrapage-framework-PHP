<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="/css/welcome.css" rel="stylesheet">

    </head>
    <body>

<!-------- Navbar ------->
        <div class="navbar">
                <a href="#" class="skip-to-main-content">skip to main content</a>
            <nav>
                <ul>
                  <a>Accueil</a>
                  <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(url('/home')); ?>" class="log">home</a>
                            <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="log">Se connecter</a>
                            <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="log">Inscription</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    <div>
        <h1 class = title>Page d'accueil</h1>
    </div>
    </body>
</html>
<?php /**PATH C:\Users\Diizo portable\Desktop\todo\resources\views/welcome.blade.php ENDPATH**/ ?>