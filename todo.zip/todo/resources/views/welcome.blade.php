<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="/css/welcome.css" rel="stylesheet">

    </head>
    <body>

<!-------- Navbar ------->
        <div class="navbar">
                <a href="#" class="skip-to-main-content">skip to main content</a>
            <nav>
                <ul>
                  <a>Accueil</a>
                  @if (Route::has('login'))
                        @auth
                            <a href="{{ url('/home') }}" class="log">home</a>
                            @else
                            <a href="{{ route('login') }}" class="log">Se connecter</a>
                            @if (Route::has('register'))
                            <a href="{{ route('register') }}" class="log">Inscription</a>
                            @endif
                        @endauth
                    @endif
                </ul>
            </nav>
        </div>
    <div>
        <h1 class = title>Page d'accueil</h1>
    </div>
    </body>
</html>
