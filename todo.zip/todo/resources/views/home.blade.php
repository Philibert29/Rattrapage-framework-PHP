@extends('layouts.app')

@section('content')
<link href="/css/home.css" rel="stylesheet">
        <div class="home">
            <div class="parallax"><h1>Rattrapage TODO</h1></div>
        </div>

        <div class="home2">

        </div>