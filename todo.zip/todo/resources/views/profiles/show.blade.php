@extends('layouts.app')

@section('content')
<link href="/css/show.css" rel="stylesheet">
<div class="div1"></div>
<div>Nom d'utilisateur : {{ $user->username }}</div>

<div class="mr-3"><strong>{{ $user->posts->count() }}</strong> publications</div>
<div class="post"><a class="" href="{{ route('posts.create') }}">Créer un post</a></div>

<div class="div2">
	@foreach ($user->posts as $post)
		<div class="col-4">
			<img src="{{ asset('storage') . '/' . $post->image }}" classe="w-100">
		</div>
	@endforeach
</div>


@endsection
